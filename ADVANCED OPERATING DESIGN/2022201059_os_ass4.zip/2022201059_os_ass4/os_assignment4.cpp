#include<linux/module.h>

// The following includes are not initially required, but have been included for Assignment #3 - Sp 2020
#include<linux/sched/signal.h>
#include<linux/pid_namespace.h>
#include<linux/cdev.h>
#include<linux/proc_fs.h>
#include<linux/slab.h>

void souma(void)
{
   struct task_struct *task;
  size_t count1 = 0,count2=0,count3=0,count=0;
for_each_process(task) {
if(task->state== TASK_RUNNING)
        count1=count1+1;
else if(task->state==TASK_INTERRUPTIBLE)
count2++;
else if(task->state== TASK_UNINTERRUPTIBLE)
count3++;
}
count=count1+count2+count3;
printk(KERN_INFO "Number of running process : %zu" ,count1);
printk(KERN_INFO "Number of interuptible process:%zu",count2);
printk(KERN_INFO "Number of uninteruptible process: %zu", count3);
printk(KERN_INFO "Number of process: %zu",count);
}
int proc_init (void) {
  printk(KERN_INFO "helloModule: kernel module initialized\n");
  souma();
  return 0;
}

void proc_cleanup(void) {
  printk(KERN_INFO "helloModule: performing cleanup of module\n");
}

MODULE_LICENSE("GPL");
module_init(proc_init);
module_exit(proc_cleanup);

