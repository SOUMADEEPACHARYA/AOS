#include<linux/syscalls.h>
#include<linux/kernel.h>
#include<linux/sched.h>
SYSCALL_DEFINE0(soumadeepgetpid)
{
	return (int)task_pid_nr(current);
}


