#include<linux/syscalls.h>
#include<linux/kernel.h>

SYSCALL_DEFINE0(soumadeephello)
{
	printk("Hello World\n");
	return 0;
}


