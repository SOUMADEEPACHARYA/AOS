#include<linux/syscalls.h>
#include<linux/kernel.h>
#include<linux/sched.h>
SYSCALL_DEFINE0(soumadeepprocess)
{
	printk("Parent Pid: %d, Current Pid:%d\n", (current->real_parent)->pid, current->pid);
	return 0;
}


