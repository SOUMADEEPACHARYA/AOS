#include<linux/syscalls.h>
#include<linux/kernel.h>

SYSCALL_DEFINE1(soumadeepprint, char *, str)
{
	char buf[256];
  	long copied = strncpy_from_user(buf, str, sizeof(buf));
  	if (copied < 0 || copied == sizeof(buf))
    		return -EFAULT;
  	printk(KERN_INFO "Welcome %s!\n", buf);
  	return 0;
}

