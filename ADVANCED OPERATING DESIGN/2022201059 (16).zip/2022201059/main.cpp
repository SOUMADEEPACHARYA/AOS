#include <bits/stdc++.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <vector>
#include <string>
#include <ctime>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>
#include <iomanip>
#include <pwd.h>
#include <fcntl.h>
#include <grp.h>
using namespace std;
#define skip 27
string cur_acc;
char Home[PATH_MAX];
int rows=0;
int c_bits=0;
struct winsize window;
string cur_dir;
struct termios tnew,told;
vector<vector<string > >records;
stack<string> stack1,stack2;
void normalMode(vector<string>);
void commandMode(vector<string> );

void enableRawMode()
{
	tcgetattr(STDIN_FILENO,&told);
	tnew=told;
	// tnew.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
	// tnew.c_oflag &= ~(OPOST);
	tnew.c_lflag &= ~(ICANON);
	tnew.c_lflag &= ~(ECHO);
	tcsetattr(STDIN_FILENO,TCSAFLUSH, &tnew);
}
void disableRawMode() {
  tcsetattr(STDIN_FILENO, TCSAFLUSH, &told);
}
void display(int l,int r)
{
	printf("\33c");
	for(int i=l;i<r;i++)
	{
		cout<<"\n";
		int len=records[i].size();
		for(int j=0;j<len;j++)
		cout<<records[i][j]<<" ";
	}
}
void storing(vector<string> v)
{
	int n=v.size();
	records.clear();
	for(int i=0;i<n;i++)
	{

		vector<string> stemp;
		string path=v[i];
		struct stat fileStat;
		stat(path.c_str(), &fileStat) ;
		string str="";
		str+=(S_ISDIR(fileStat.st_mode)) ? "d" : "-";
		str+=(fileStat.st_mode & S_IRUSR) ? "r" : "-";
		str+=(fileStat.st_mode & S_IWUSR) ? "w" : "-";
		str+=(fileStat.st_mode & S_IXUSR) ? "x" : "-";
		str+=(fileStat.st_mode & S_IRGRP) ? "r" : "-";
		str+= (fileStat.st_mode & S_IWGRP) ? "w" : "-";
		str+= (fileStat.st_mode & S_IXGRP) ? "x" : "-";
		str+=(fileStat.st_mode & S_IROTH) ? "r" : "-";
		str+=(fileStat.st_mode & S_IWOTH) ? "w" : "-";
		str+=(fileStat.st_mode & S_IXOTH) ? "x" : "-";
		stemp.push_back(str);
		stemp.push_back(to_string(fileStat.st_size));
		stemp.push_back(getpwuid(fileStat.st_uid)->pw_name);
		stemp.push_back(getgrgid(fileStat.st_gid)->gr_name);
		string wt=ctime(&(fileStat.st_mtime));
	    wt.pop_back();
		stemp.push_back(wt);
		stemp.push_back(path.substr(path.find_last_of("/\\")+1));
		
		records.push_back(stemp);
		
	}
	if(rows<v.size())
	n=rows;
	else n=v.size();
	display(0,n);
}
string find_path(string path)
{
    string abs_path = "";
	

    if (path[0] == '~') 
	{
        abs_path = string(Home) + path.substr(1, path.length());
		return abs_path;
	}
   
     if (path[0] == '/') 
	 {
        abs_path = string(Home) + path;
		return abs_path;
	 }
    
    if (path[0] == '.' && path[1] == '/') 
	{
        abs_path = cur_dir + path.substr(1, path.length());
		return abs_path;
	}
    abs_path = cur_dir + "/" + path;
    
    return abs_path;
}

void directoryList(const char* dirname)
{
	vector<string> files;
	DIR *dir =opendir(dirname);
	if(dir == NULL)
	{
		printf("error");
		return ;
	}
	struct dirent *entity;
	while((entity=readdir(dir))!=NULL)
	{
		string s=dirname;
		s+="/";
		s+=entity->d_name;
		files.push_back(s);
	}
	closedir(dir);
	sort(files.begin(),files.end());
	cur_dir="";
	int k=files[0].size()-2;
	for(int i=0;i<k;i++)
	cur_dir+=files[0][i];
	// int n;
	// if(rows<files.size())
	// n=rows;
	// else n=files.size();
	// display(files,0,n);
	storing(files);
	if(c_bits==0)
	normalMode(files);
	else
	commandMode(files);

}
mode_t get_mode(string src)
{
	 mode_t m=0;
    struct stat inode;
    stat(src.c_str(), &inode);
    
    
    
    m = m | ((inode.st_mode & S_IROTH)?0004:0);
    m = m | ((inode.st_mode & S_IWOTH)?0002:0);
    m = m | ((inode.st_mode & S_IXOTH)?0001:0);
	 m = m | ((inode.st_mode & S_IRGRP)?0040:0);
    m = m | ((inode.st_mode & S_IWGRP)?0020:0);
    m = m | ((inode.st_mode & S_IXGRP)?0010:0);

    m = m | ((inode.st_mode & S_IRUSR)?0400:0);
    m = m | ((inode.st_mode & S_IWUSR)?0200:0);
    m = m | ((inode.st_mode & S_IXUSR)?0100:0);
    

    return m;
}
void normalMode(vector<string> files)
{
	
	int n;
	if(rows<files.size())
	n=rows;
	else n=files.size();
	
	int x=n+7,y=0;
	printf("%c[%d;%dH",skip,x,y);
	cout<<"NORMAL MODE";
	cout<<"\n";
	x=1,y=0;
	
	printf("%c[%d;%dH",skip,x,y);
	 printf("\n");
	 int pos=1;
	 int lm=1;

	while(1)
	{
		int val=0;
		 enableRawMode();
		val=cin.get();
		 disableRawMode();
		 if(val==65)
		 {
			if(lm>1)
			{
				if(pos>1)
				{
					lm--;pos--;
				printf("\033[1A");
				}
				else if(lm>1)
				{
					lm--;
				
					int f=lm-1;
					int l=lm+rows-1;
					display(f,l);
					int x=rows+7,y=0;
					printf("%c[%d;%dH",skip,x,y);
					cout<<"NORMAL MODE";
					cout<<"\n";
					x=1,y=0;
					
					printf("%c[%d;%dH",skip,x,y);
					printf("\n");
				}
				
			}

		 }
		 else if(val==66)
		 {
	
			if(pos<n)
			{
				printf("\033[1B");
				pos++;
				lm++;
			}
			else if(lm>=rows &&files.size()>lm)
			{
				int f=lm-rows+1;
				int l=lm+1;
				display(f,l);
				int x=rows+7,y=0;
				printf("%c[%d;%dH",skip,x,y);
				cout<<"NORMAL MODE";
				cout<<"\n";
				x=rows,y=0;
				
				printf("%c[%d;%dH",skip,x,y);
				printf("\n");
				lm++;
			}
		 }
		  else if(val==10)
		 {
			if(lm>0)
			{
				
				struct stat node;
				string lstr=files[lm-1];
				stat(lstr.c_str(),&node);
				if(S_ISDIR(node.st_mode))
				{
					stack2.push(cur_acc);	
					if(lm==2)
					{
						
						string head=cur_acc;
						int l=head.size();
						while(l>0)
						{
							l--;
							char c=head[l];
							head.pop_back();
							if(c=='/')
							break;
						}
						cur_acc=head;
						directoryList(&head[0]);
					}
					else
					{
						
						
						cur_acc=files[lm-1];
					   directoryList(&files[lm-1][0]);
					}
					while(!stack1.empty())
					stack1.pop();

				}
				else 
				{
					if(fork()==0)
					{
						execl("/usr/bin/xdg-open","xdg-open",&files[lm-1][0],(char *)0);
						exit(1);
					}
				}
			}

		 }
		else if(val==67)
		{
			if(!stack1.empty())
			{
				string str=stack1.top();
				stack1.pop();
				 stack2.push(cur_acc);
				 cur_acc=str;
				 directoryList(&str[0]);

			}
		}
		else if(val==68)
		{
			if(!stack2.empty())
			{
				string str=stack2.top();
				stack2.pop();
				stack1.push(cur_acc);
				cur_acc=str;
			   directoryList(&str[0]);

			}
		}
		else if(val==127)
		{
			stack2.push(cur_acc);
			string head=cur_acc;
			int l=head.size();
			while(l>0)
			{
				l--;
				char c=head[l];
				head.pop_back();
				if(c=='/')
				break;
			}
			cur_acc=head;
			directoryList(&head[0]);
			while(!stack1.empty())
			stack1.pop();
		}
		else if(val==104)
		{
			while(!stack1.empty())
					stack1.pop();
			stack2.push(cur_acc);
			cur_acc=Home;
			directoryList(Home);
		}
		else if(val==58)
		{
			c_bits=1;
			printf("%c[%d;%dH",skip,n+7,y);
			printf("\n");
			cout<<"\33[K\r";
			commandMode(files);
		}
		// else if(val==113)
		// {
		// 	int u=rows+7;
		// 	int v=0;
		// 	printf("%c[%d;%dH",skip,u,v);
		// 	printf("\n");
		// 	printf("%c[%dK",skip,2);
		// 	exit(1);
		// }




	}

}

void copy_f(string src, string dest)
{
	mode_t m=get_mode(src);
	char c;
	int f1=open(src.c_str(),O_RDONLY);
	int f2=open(dest.c_str(),O_WRONLY|O_CREAT,m);
	if(f1==-1||f2==-1)
	{
		cout<<"file cant open\n";
		return;
	}
	while(read(f1,&c,1))
	{
		write(f2,&c,1);
	}
	close(f2);
	close(f1);
}
void copy_d(string src, string dest)
{
	struct dirent* sd;
	
	cout<<src<<" "<<dest;
	DIR *dir =opendir(src.c_str());
	if(dir != NULL)
	{
		while((sd=readdir(dir))!=NULL)
		{
			string xyz=sd->d_name;
			if(xyz!="."&&xyz!="..")
			{
				string s1=src+"/"+xyz;
				string s2=dest+"/"+xyz;
				struct stat inode;
				
				if(stat(s1.c_str(),&inode)!=0)
				copy_f(s1,s2);
				else if(S_ISDIR(inode.st_mode))
				{
					
					mode_t m=get_mode(s1);
					mkdir(dest.c_str(),m);
					copy_d(s1,s2);
				}
				else
				copy_f(s1,s2);

			}
		}

	}
	else{
		cout<<"the folder cant be open\n";
		return;
	}
}
void copy(vector<string> com)
{
		
	if(com.size()<=2)
	{
		cout<<"Error: incomplete command\n";
		return ;
	}
	string d_path=com[com.size()-1];
	string dest=find_path(d_path);
	struct stat sti;
	stat(dest.c_str(),&sti);
	if(!S_ISDIR(sti.st_mode))
	{
		printf("given destination is not folder\n");
		return;
	}
	int n=com.size();
	string sou;
	for(int i=1;i<n-1;i++)
	{
		sou=find_path(com[i]);
		int fl=0;
		int sizet=com[i].size();
		mode_t mode=get_mode(sou);
		for(int i1=0;i1<sizet;i1++)
		{
			if(com[i][i1]=='/')
			fl=i1+1;
		}
		string exten=com[i].substr(fl,sizet-fl);
		dest=dest+'/'+exten;
		struct stat inode;
		stat(sou.c_str(),&inode);
		
		if(S_ISDIR(inode.st_mode))
		{
			mkdir(dest.c_str(),mode);
			copy_d(sou,dest);
		}
		else
		copy_f(sou,dest);
	}
}
void create_file(vector<string>com)
{
	
	if(com.size()==1)
	printf("enter filename");
	else if(com.size()==2)
	printf("enter destination folder");
	else if(com.size()==3)
	{
		
		string nf=com[1];
		string df=find_path(com[2]);
		df=df+"/"+nf;
		// ioctl(STDIN_FILENO,TIOCGWINSZ,&window);
    	// rows=window.ws_row-8;
		if(creat(df.c_str(),0600)!=-1)
		directoryList(cur_acc.c_str());
		else
		cout<<"cant possible";

	}
	else 
	printf("INVALID");
}
void create_dir(vector<string> com)
{
	if(com.size()==1)
	printf("error:enter directory name");
	else if(com.size()==2)
	printf("error:enter destination folder");
	else if(com.size()==3)
	{
		
		string nf=com[1];
		string df=find_path(com[2]);
		df=df+"/"+nf;
		// ioctl(STDIN_FILENO,TIOCGWINSZ,&window);
    	// rows=window.ws_row-8;
		if(creat(df.c_str(),0755)!=-1)
		directoryList(cur_acc.c_str());
		else
		cout<<"cant possible";

	}
	else 
	printf("INVALID");
}
void goto_cm(vector<string> com)
{
	if(com.size()==1)
	printf("error:enter directory name");
	else if(com.size()==2)
	{
		string xstr=com[1];
		xstr=find_path(xstr);
		int sizet=xstr.size();
		int fl=0;
		
		for(int i1=0;i1<sizet;i1++)
		{
			if(xstr[i1]=='/')
			fl=i1+1;
		}
		string exten=xstr.substr(fl,sizet-fl);
		if(exten==".")
		return;
		stack2.push(cur_acc);
	
		directoryList(xstr.c_str());

	}
}
void rename_cm(vector<string>com)
{
	cout<<"hi";
	if(com.size()==3)
	{
		cout<<"hi1";
		string dstr=find_path(com[2]);
		string sstr=find_path(com[1]);

		int sizet=sstr.size();
		int fl=0;
		
		for(int i1=0;i1<sizet;i1++)
		{
			if(sstr[i1]=='/')
			fl=i1+1;
		}
		string exten=sstr.substr(fl,sizet-fl);

		int sizet2=dstr.size();
		int fl2=0;
		
		for(int i1=0;i1<sizet2;i1++)
		{
			if(dstr[i1]=='/')
			fl2=i1+1;
		}

		string exten2=dstr.substr(fl2,sizet2-fl2);
		dstr="";
		for(int i=0;i<fl;i++)
		{
			dstr+=sstr[i];
		}
		dstr+=exten2;
		cout<<sstr<<" "<<dstr<<" ";
		if(rename(sstr.c_str(),dstr.c_str())!=-1)
		directoryList(cur_acc.c_str());
		else{
			cout<<"operation can't be permitted";
		}


	}
}
void commandMode(vector<string> files)
{
	int n;
	if(rows<files.size())
	n=rows;
	else n=files.size();
	int x=n+7,y=0;
	printf("%c[%d;%dH",skip,x,y);
	printf("Command Mode");
	printf("\n");
	y=14;
	printf("%c[%d;%dH",skip,x,y);
	
	string cm="";
	vector<string> comdata;
	while(1)
	{
		char val=0;
		 enableRawMode();
		val=cin.get();
		  disableRawMode();
		 if(val==10)
	    {
			y=0;
			printf("%c[%d;%dH",skip,x,y);
			printf("Command Mode");
			printf("\n");
			y=14;
			printf("%c[%d;%dH",skip,x,y);
			int csize=cm.size(),fi=0,sl=0;
			string sst="";
			for(int i=0;i<csize;i++)
			{
				if(cm[i]==' ')
				{
				    sst=cm.substr(fi,sl);
					sl=0;
					comdata.push_back(sst);
					fi=(i+1);
				}
				else{
					sl++;
				}
			}
		    sst=cm.substr(fi,sl);
			
			if(sst!="")
			comdata.push_back(sst);
			
			
			
			if(comdata[0]=="copy")
			{
	        	copy(comdata);
				// y=14;
				// x=n+7;
				// printf("%c[%d;%dH",skip,x,y);
				// cout<<"\33[K\r";
			}
			// else if(comdata[0]=="search")
			// search(comdata);
			else if(comdata[0]=="rename")
			rename_cm(comdata);
			// else if(comdata[0]=="move")
			// move(comdata);
			 else if(comdata[0]=="create_file")
			create_file(comdata);
			// else if(comdata[0]=="delete_file")
			// delete_file(comdata);
			else if(comdata[0]=="create_dir")
			create_dir(comdata);
			// else if(comdata[0]=="delete_dir")
			// delete_dir(comdata);
			 else if(comdata[0]=="goto")
			 goto_cm(comdata);

	    }
		else if(val==27)
		{
			c_bits=0;
			printf("%c[%d;%dH",skip,x,0);
			cout<<"\33[K\r";
			cout<<flush;
			normalMode(files);

		}
		else
		{
			printf("%c[%d;%dH",skip,x,y);
			cm+=val;
			cout<<cm;

		}
	}


}
signed main()
{
	getcwd(Home,sizeof(Home));
	//  string Home="/Users/soumadeepacharya/Documents";
	vector<string> v;
	ioctl(STDIN_FILENO,TIOCGWINSZ,&window);

	rows=window.ws_row-8;
	// string path="/Users/soumadeepacharya/Documents";
	cur_acc=Home;
	directoryList(Home);
	

}